export type UsersTypes = {
  id: number;
  address: string;
  company_name: string;
  email: string;
  owner_name: string;
  phone: string;
  password: string;
  restaurant_id: number;
  restaurant_name: string;
  restaurant_version: number;
  role_id: number;
};

import { Space, Tag } from "antd";
import type { TableProps } from "antd";
import { Link } from "react-router-dom";
import { DataType } from "../page/PassportManagement";
import ViewButton from "../../../common/CommonAnt/Button/ViewButton";
import EditButton from "../../../common/CommonAnt/Button/EditButton";

export const columns: TableProps<DataType>["columns"] = [
  {
    title: "Name",
    dataIndex: "name",
    key: "name",
    render: (text) => <a>{text}</a>,
  },
  {
    title: "Age",
    dataIndex: "age",
    key: "age",
  },
  {
    title: "Address",
    dataIndex: "address",
    key: "address",
  },
  {
    title: "Tags",
    key: "tags",
    dataIndex: "tags",
    render: (_, { tags }) => (
      <>
        {tags.map((tag) => {
          let color = tag.length > 5 ? "geekblue" : "green";
          if (tag === "loser") {
            color = "volcano";
          }
          return (
            <Tag color={color} key={tag}>
              {tag.toUpperCase()}
            </Tag>
          );
        })}
      </>
    ),
  },
  {
    title: "Action",
    key: "action",
    render: (record) => (
      <Space size="middle" key={record?.id}>
        <Link to="/passport/passport-view/1">
          <ViewButton to="/passport/passport-view/1">View</ViewButton>
        </Link>
        <EditButton>Edit</EditButton>
      </Space>
    ),
  },
];

export const data: DataType[] = [
  {
    key: "1",
    name: "John Brown",
    age: 32,
    address: "New York No. 1 Lake Park",
    tags: ["nice", "developer"],
  },
  {
    key: "2",
    name: "Jim Green",
    age: 42,
    address: "London No. 1 Lake Park",
    tags: ["loser"],
  },
  {
    key: "3",
    name: "Joe Black",
    age: 32,
    address: "Sydney No. 1 Lake Park",
    tags: ["cool", "teacher"],
  },
];
